# Mother's Day Vercel React App

This is a Vite + React website with Framer Motion animations, confetti, interactive photo cards, pop-up letter, and embedded photos.

## How to run locally
npm install
npm run dev

## How to deploy on Vercel from iPad
1. Upload this folder to GitHub.
2. Go to Vercel.
3. Import the GitHub repository.
4. Framework preset: Vite.
5. Build command: npm run build
6. Output directory: dist
7. Deploy.
