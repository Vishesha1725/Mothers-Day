
import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { Heart, Sparkles, Gift, X, Music2, Camera, MailHeart, Wand2 } from "lucide-react";
import "./style.css";

import p1 from "./assets/photo1.jpeg";
import p2 from "./assets/photo2.jpeg";
import p3 from "./assets/photo3.jpeg";
import p4 from "./assets/photo4.jpeg";
import p5 from "./assets/photo5.jpeg";
import p6 from "./assets/photo6.jpeg";
import p7 from "./assets/photo7.jpeg";
import p8 from "./assets/photo8.jpeg";

const photos = [
  { img: p1, title: "Day one drama", text: "From tiny me to 21-year-old me, you have been handling my tantrums like a full-time job." },
  { img: p2, title: "My safest place", text: "Maa, duniya kitni bhi loud ho, your hug still feels like home." },
  { img: p3, title: "Tiny me, patient you", text: "You survived my crying, my stubbornness, my mood swings, and somehow still love me." },
  { img: p4, title: "Main character energy", text: "Every good memory has you quietly making it warmer in the background." },
  { img: p5, title: "Certified baby", text: "I may be 21, but emotionally I am still your little baby who needs Maa approval." },
  { img: p6, title: "Movie scene memory", text: "If life is a Bollywood film, you are the song that makes everything emotional and beautiful." },
  { img: p7, title: "Forever favourite", text: "Meri maa, meri comfort person, meri unpaid therapist, meri best friend." },
  { img: p8, title: "Warmest hug", text: "Cold weather, warm hugs, and you. Perfect combination." },
];

const notes = [
  "Maa ka patience level: infinity",
  "Thank you for tolerating my nautanki since birth",
  "Aap meri safe place ho",
  "Still your baby at 21",
  "Meri maa > literally everyone",
  "No one loves me like you do",
  "I am your cutest headache",
  "Aap ho toh sab manageable lagta hai",
  "Emotional damage button ahead",
  "Warning: cringe but true"
];

function burst() {
  confetti({ particleCount: 140, spread: 85, origin: { y: 0.65 } });
  setTimeout(() => confetti({ particleCount: 80, spread: 120, origin: { y: 0.7 } }), 350);
}

function FloatingThings() {
  const items = useMemo(() => Array.from({ length: 30 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 8,
    duration: 8 + Math.random() * 8,
    size: 16 + Math.random() * 20,
    icon: ["♡", "✦", "❀", "✧", "♥"][Math.floor(Math.random() * 5)]
  })), []);
  return <div className="float-layer">
    {items.map(item => <span key={item.id} style={{
      left: `${item.left}%`,
      animationDelay: `${item.delay}s`,
      animationDuration: `${item.duration}s`,
      fontSize: `${item.size}px`
    }}>{item.icon}</span>)}
  </div>;
}

function App() {
  const [selected, setSelected] = useState(null);
  const [letter, setLetter] = useState(false);
  const [jarOpen, setJarOpen] = useState(false);
  const [secret, setSecret] = useState("Tap the jar for a random Maa appreciation note.");

  const randomSecret = () => {
    const lines = [
      "Maa, thank you for loving me even when I am being impossible.",
      "Aap meri life ki permanent good luck charm ho.",
      "I know I trouble you, but I also love you the most.",
      "Thank you for being my home, my strength, and my soft corner.",
      "Main kitni bhi badi ho jaun, mujhe Maa toh chahiye hi.",
      "You deserve flowers, peace, and zero tantrums from me. But I can only promise flowers."
    ];
    setJarOpen(true);
    setSecret(lines[Math.floor(Math.random() * lines.length)]);
    burst();
  };

  return (
    <main>
      <FloatingThings />

      <section className="hero">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1 }} className="glass">
          <div className="pill"><Sparkles size={16}/> made with excessive love and mild drama</div>
          <h1>Happy Mother’s Day, Maa</h1>
          <p>For the woman who has handled my tantrums from the day I was born till I am 21, and still somehow calls me her baby.</p>
          <div className="hero-actions">
            <button onClick={() => document.getElementById("memories").scrollIntoView({ behavior: "smooth" })}><Camera size={18}/> open memories</button>
            <button className="secondary" onClick={() => { setLetter(true); burst(); }}><MailHeart size={18}/> open letter</button>
          </div>
        </motion.div>
      </section>

      <section className="ticker">
        <div>{notes.concat(notes).map((n, i) => <span key={i}>{n}</span>)}</div>
      </section>

      <section id="memories" className="memories">
        <motion.h2 initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>our tiny scrapbook</motion.h2>
        <p className="sub">Tap every photo. Each one has a small dramatic love note.</p>

        <div className="grid">
          {photos.map((p, i) => (
            <motion.div
              className="card"
              key={p.title}
              initial={{ opacity: 0, y: 60, rotate: i % 2 ? 4 : -4 }}
              whileInView={{ opacity: 1, y: 0, rotate: i % 2 ? 3 : -3 }}
              whileHover={{ scale: 1.04, rotate: 0 }}
              transition={{ duration: 0.55, delay: i * 0.05 }}
              viewport={{ once: true }}
              onClick={() => { setSelected(p); burst(); }}
            >
              <img src={p.img} />
              <h3>{p.title}</h3>
              <small>tap to open</small>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="interactive">
        <motion.div className="jar" onClick={randomSecret} whileTap={{ scale: 0.95 }}>
          <Gift size={54}/>
          <h2>Tap the jar of love notes</h2>
          <p>{secret}</p>
          {jarOpen && <span className="stamp">opened</span>}
        </motion.div>

        <motion.div className="playlist" whileHover={{ rotate: 1 }}>
          <Music2 size={42}/>
          <h2>Bollywood emotional section</h2>
          <p>Because every Maa deserves one slow-motion entry, one emotional background song, and one dramatic child saying: “Maa, aap ho toh sab hai.”</p>
        </motion.div>
      </section>

      <section className="final">
        <Wand2 size={38}/>
        <h2>Final truth</h2>
        <p>Maa, I may act grown up, but I am still the same child who looks for you first. Thank you for being my home, my protection, my comfort, and my forever person.</p>
        <button onClick={() => { setLetter(true); burst(); }}>Read the full letter</button>
      </section>

      <AnimatePresence>
        {selected && (
          <motion.div className="modal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div className="modal-card" initial={{ scale: 0.82, y: 40 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }}>
              <button className="close" onClick={() => setSelected(null)}><X/></button>
              <img src={selected.img}/>
              <h2>{selected.title}</h2>
              <p>{selected.text}</p>
            </motion.div>
          </motion.div>
        )}

        {letter && (
          <motion.div className="modal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div className="letter" initial={{ rotateX: 45, scale: 0.85 }} animate={{ rotateX: 0, scale: 1 }} exit={{ scale: 0.9 }}>
              <button className="close" onClick={() => setLetter(false)}><X/></button>
              <h2>Dear Maa,</h2>
              <p>
                Thank you for handling my tantrums since the day I was born till now, when I am 21 and still fully dramatic.
                You have seen every version of me — crying baby, stubborn child, confused teenager, overthinking adult — and you still love me like I am the best thing in the world.
              </p>
              <p>
                Aap meri maa hi nahi, meri safest place ho. Jab life overwhelming lagti hai, your voice, your food, your hug, and even your scolding make everything feel normal again.
              </p>
              <p>
                I know I trouble you, annoy you, ask too many things, and sometimes act like a full-time headache. But please know this: I love you more than I say, more than I show, and more than words can fit on this tiny website.
              </p>
              <h3>Happy Mother’s Day, Maa. Still your baby. Always.</h3>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
